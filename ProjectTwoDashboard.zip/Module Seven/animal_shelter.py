from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """
    
    def __init__(self, username, password):
        # init to connect to mongodb with no auth
        self.client = MongoClient('mongodb://localhost:53080')
        # init to connect to mongodb with auth
        #self.client = MongoClient('mongodb://%s:%s@localhost:53080/?authMechanism=DEFAULT&authSource=AAC'%(username, password))
        self.database = self.client['AAC']
        
# Create method to implement the C in CRUD.
    def create(self, data):
        if data is not None:
            self.database.animals.insert(data) # data should be a dictionary
            return True
        else:
            raise Exception("Nothing to save, because data parameter is empty")
            
# Read methods to implement the R in CRUD.
    def read(self, data):
        if data is not None:
            return self.database.animals.find_one(data)  # returns one document
        else:
            print("Nothing to read, because data parameter is empty")
    
    def read_all(self, data):
        cursor = self.database.animals.find(data, {'_id':False}) # return cursor with pointer to list of results excluding _id
        return cursor
    
# Update method to implement the U in CRUD.
    def update(self, query, record):
        if record is not None:
            return self.database.animals.update_many(query, record) # updates database with new records
        else:
            raise Exception("No record found")

# Delete method to implement the D in CRUD.
    def delete(self, data):
        if data is not None:
            return self.database.animals.delete_one(data) # deletes data from the database
        else:
            raise Exception("No record entered")
